package com.pingplusplus.model;

public class CardCollection extends PingppCollection<Card> {
}
