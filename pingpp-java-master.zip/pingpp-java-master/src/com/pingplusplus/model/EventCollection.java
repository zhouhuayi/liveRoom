package com.pingplusplus.model;

public class EventCollection extends PingppCollection<Event> {
}
