package com.pingplusplus.model;

public class RedEnvelopeCollection extends PingppCollection<RedEnvelope> {
}
