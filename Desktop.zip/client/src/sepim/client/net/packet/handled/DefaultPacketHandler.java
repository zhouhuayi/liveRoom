package sepim.client.net.packet.handled;

import sepim.client.net.packet.Packet;

public class DefaultPacketHandler {
	
	public void handle(Packet packet) {

	}

}
